#!/usr/bin/env python3
#!/#path/#to/#python
import rospy
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry 



def callback(data):
      global orientationb
      orientationb = data.pose.pose.position.y
      global pub, pubBrake , pub_steer
      pub = rospy.Publisher("/cmd_vel", Float64, queue_size=0)
      pubBrake = rospy.Publisher('/brakes',Float64, queue_size=0)
      pub_steer = rospy.Publisher("/SteeringAngle", Float64, queue_size=0)
      #rate = rospy.Rate(10)
      pub.publish(0.3)
      pub_steer.publish(8)

      
        
      #while not rospy.is_shutdown():   
       #     if orientationb < 7:
             
        #    else:
         #    pub.publish(0)
          #    
           #  pubBrake.publish(1)
            # break
      
             
    
def listener():
     rospy.Subscriber("/odom",Odometry,callback)
     rospy.spin()

      
    

if __name__=='__main__':
    rospy.init_node('pionner_control',anonymous=True)
    listener()

    