#!/usr/bin/env python3


import rospy
from std_msgs.msg import Float64
from nav_msgs.msg import Odometry 
import matplotlib.pyplot as plt
import numpy as np
import time

orientationb = 0
def callback(data):
      global orientationb
      orientationb = data.pose.pose.position.y
      global pub, pubBrake , pub_steer
      pub = rospy.Publisher("/cmd_vel", Float64, queue_size=0)
      pubBrake = rospy.Publisher('/brakes',Float64, queue_size=0)
      pub_steer = rospy.Publisher("/SteeringAngle", Float64, queue_size=10)
      rate = rospy.Rate(10)

      start_time = rospy.Time.now()
    
      elapsed_time = (rospy.Time.now() - start_time).to_sec()
        
      while not rospy.is_shutdown():   
            if elapsed_time < 7:
             pub.publish(0.25)
             pub_steer.publish(12)
            else:
             pub.publish(0)
              
             pubBrake.publish(1)
             break
      rate.sleep()
             
    
def listener():
     rospy.Subscriber("/odom",Odometry,callback)
     rospy.spin()

      
    

if __name__=='__main__':
    rospy.init_node('pionner_control',anonymous=True)
    listener()

    